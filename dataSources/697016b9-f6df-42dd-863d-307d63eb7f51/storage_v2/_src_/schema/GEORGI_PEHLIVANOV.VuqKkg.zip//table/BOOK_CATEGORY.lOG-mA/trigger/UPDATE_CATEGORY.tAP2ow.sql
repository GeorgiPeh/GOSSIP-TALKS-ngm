create trigger UPDATE_CATEGORY
    before delete
    on BOOK_CATEGORY
    for each row
BEGIN
DELETE FROM
    books
WHERE books.category_id = :old.category_id;
END;
/

