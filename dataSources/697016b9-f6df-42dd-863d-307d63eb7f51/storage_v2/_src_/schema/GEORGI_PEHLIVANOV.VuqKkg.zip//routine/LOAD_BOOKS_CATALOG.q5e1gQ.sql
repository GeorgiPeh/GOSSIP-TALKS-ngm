create PROCEDURE load_books_catalog
AS
TRUNCATE TABLE books_catalog;
v_insertion_date := SYSDATE();
BEGIN
INSERT INTO books_catalog(author_first_name, author_last_name, book_name, category_name, insertion_date)
SELECT b.author_first_name, b.author_last_name, b.book_name, g.category_name, v_insertion_date
FROM books b
    INNER JOIN book_category g 
    ON b.category_id = g.category_id;
    COMMIT;
END LOAD_BOOKS_CATALOG;
/

