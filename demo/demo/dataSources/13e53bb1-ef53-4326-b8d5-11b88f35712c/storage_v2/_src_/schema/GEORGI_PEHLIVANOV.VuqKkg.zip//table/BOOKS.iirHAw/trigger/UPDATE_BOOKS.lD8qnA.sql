create trigger UPDATE_BOOKS
    after update of BOOK_ID,BOOK_NAME
    on BOOKS
    for each row
BEGIN
INSERT INTO old_books VALUES
(:OLD.BOOK_ID,
:OLD.BOOK_NAME,
SYSDATE);
END;
/

